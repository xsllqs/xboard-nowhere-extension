#!/usr/bin/env bash
# Install/upgrade the standalone extension. Does not replace xboard-node itself.
set -euo pipefail
umask 077
BASE=/opt/xboard-node/extensions/nowhere
CONFIG=/etc/xboard-node/extensions/nowhere
STATE=/var/lib/xboard-node/nowhere
UNIT=/etc/systemd/system/xboard-node-nowhere-managed.service
HERE=$(cd -- "$(dirname -- "$0")" && pwd -P)
mode=install;panel='';secret='';backup='';machine=''
while (($#));do
  case "$1" in
    --check) mode=check;shift ;;
    --repair-cli) mode=repair;shift ;;
    --rollback) mode=rollback;backup=${2:?backup directory required};shift 2 ;;
    --machine-id) machine=${2:?machine ID required};shift 2 ;;
    --panel) panel=${2:?HTTPS panel required};shift 2 ;;
    --secret-file) secret=${2:?secret file required};shift 2 ;;
    *) echo "Unknown option: $1" >&2;exit 2 ;;
  esac
done
((EUID==0)) || { echo 'Run as root' >&2;exit 1; }
command -v systemctl >/dev/null
repair_cli() {
  local source=$HERE/xbctl-wrapper
  [[ -f "$source" ]] || { echo 'Wrapper missing in extension release' >&2;return 1; }
  install -d -m755 /usr/local/lib/xboard-node
  if [[ -f /usr/local/bin/xbctl ]] && ! grep -aq XBOARD_NOWHERE_EXTENSION_WRAPPER /usr/local/bin/xbctl;then
    install -m755 /usr/local/bin/xbctl /usr/local/lib/xboard-node/xbctl-upstream
  fi
  [[ -x /usr/local/lib/xboard-node/xbctl-upstream ]] || { echo 'Install official xbctl first' >&2;return 1; }
  install -m755 "$source" /usr/local/bin/xbctl
  ln -sfn /usr/local/bin/xbctl /usr/bin/xbctl
}
if [[ "$mode" == repair ]];then repair_cli;exit;fi
systemctl cat xboard-node.service >/dev/null
if [[ "$mode" == rollback ]];then
  backup=$(realpath -- "$backup")
  [[ "$backup" == "$BASE/backups/"* && -f "$backup/previous-release" ]] || { echo 'Invalid extension backup' >&2;exit 1; }
  previous=$(cat "$backup/previous-release")
  if [[ -f "$CONFIG/security-v3" && -f "$previous/VERSION" ]];then
    previous_version=$(cat "$previous/VERSION")
    [[ "$previous_version" != 0.[0-8].* ]] || { echo 'Security migration cannot roll back to a shared-key agent. Install an audited 0.9+ release; usage retained.' >&2;exit 1; }
  fi
  systemctl stop xboard-node-nowhere-managed.service
  if [[ "$previous" == "$BASE/releases/"* && -x "$previous/nowhere-agent" ]];then
    ln -sfn "$previous" "$BASE/current.next";mv -Tf "$BASE/current.next" "$BASE/current"
  elif [[ ! -f "$backup/unit" ]];then
    systemctl disable xboard-node-nowhere-managed.service >/dev/null || true
    rm -f "$UNIT"
    install -m755 /usr/local/lib/xboard-node/xbctl-upstream /usr/local/bin/xbctl
    systemctl daemon-reload
    echo 'First installation rolled back; usage and configuration retained'
    exit
  fi
  if [[ -f "$backup/unit" ]];then install -m644 "$backup/unit" "$UNIT";fi
  if [[ -f "$backup/agent.env" ]];then install -m600 "$backup/agent.env" "$CONFIG/agent.env";fi
  systemctl daemon-reload
  "$BASE/current/install.sh" --repair-cli
  systemctl start xboard-node-nowhere-managed.service
  echo "Rolled back to $previous; live usage state retained"
  exit
fi
for file in nowhere-agent nowhere ctl xbctl-wrapper SHA256SUMS;do [[ -f "$HERE/$file" ]] || { echo "Missing release file: $file" >&2;exit 1; };done
(cd "$HERE" && sha256sum --check --status SHA256SUMS)
[[ $(uname -m) == x86_64 ]] || { echo 'This release is for Linux amd64' >&2;exit 1; }
"$HERE/nowhere" --version >/dev/null
"$HERE/nowhere-agent" -h >/dev/null 2>&1
[[ -x /usr/local/bin/xbctl || -x /usr/local/lib/xboard-node/xbctl-upstream ]] || { echo 'Install official xbctl first' >&2;exit 1; }
if [[ -z "$panel" && -f "$CONFIG/agent.env" ]];then panel=$(sed -n 's/^PANEL_URL=//p' "$CONFIG/agent.env");fi
[[ "$panel" =~ ^https://[a-zA-Z0-9.-]+(:[0-9]+)?/?$ ]] || { echo 'A plain HTTPS panel origin is required' >&2;exit 1; }
if [[ -z "$machine" && -f "$CONFIG/agent.env" ]];then machine=$(sed -n 's/^MACHINE_ID=//p' "$CONFIG/agent.env");fi
if [[ -z "$machine" ]];then
  machine=$(python3 - <<'PYID'
import re
from pathlib import Path
p=Path('/etc/xboard-node/config.yml')
ids=re.findall(r'^\s*machine_id:\s*["\']?(\d+)',p.read_text() if p.exists() else '',re.M)
if len(set(ids))==1:print(ids[0])
PYID
)
fi
[[ "$machine" =~ ^[1-9][0-9]*$ ]] || { echo 'Pass --machine-id matching the bound Xboard server' >&2;exit 1; }
if [[ -z "$secret" ]];then secret=$CONFIG/control.secret;fi
[[ -f "$secret" && ! -L "$secret" ]] || { echo 'Control secret file is missing or is a symlink' >&2;exit 1; }
[[ $(tr -d '\r\n' < "$secret" | wc -c) -ge 32 ]] || { echo 'Control secret must have at least 32 characters' >&2;exit 1; }
python3 - "$panel" "$secret" "$machine" <<'PY'
import json,sys,urllib.request
from pathlib import Path
request=urllib.request.Request(sys.argv[1].rstrip('/')+'/api/v1/nowhere/control',data=json.dumps({'reports':[],'machine_id':int(sys.argv[3]),'protocol_version':3}).encode(),headers={
 'Authorization':'Bearer '+Path(sys.argv[2]).read_text().strip(),'Content-Type':'application/json','User-Agent':'Xboard-Node-Nowhere/0.5'})
try:
 with urllib.request.urlopen(request,timeout=12) as r: config=json.load(r)
 assert config.get('protocol_version')==3 and isinstance(config.get('nodes'),list)
 assert config.get('sync_settings',{}).get('device_mode')=='native_snapshot','Update panel plugin first'
except Exception as error:
 raise SystemExit('Panel authentication/compatibility check failed: '+type(error).__name__)
print('Panel authentication OK; nodes='+str(len(config['nodes']))+', users='+str(sum(len(n['users']) for n in config['nodes'])))
PY
version=$(cat "$HERE/VERSION")
[[ "$version" =~ ^[a-zA-Z0-9._-]+$ ]] || { echo 'Invalid release version' >&2;exit 1; }
release="$BASE/releases/$version"
if [[ "$mode" == check ]];then echo "Preflight OK: release $version, panel $panel; no changes made";exit;fi
install -d -m755 "$BASE/releases" "$BASE/backups"
install -d -m700 "$CONFIG" "$STATE"
backup="$BASE/backups/$(date +%Y%m%d-%H%M%S)-$$"
install -d -m700 "$backup"
readlink -f "$BASE/current" > "$backup/previous-release" 2>/dev/null || true
[[ ! -f "$UNIT" ]] || cp -a "$UNIT" "$backup/unit"
[[ ! -f "$CONFIG/agent.env" ]] || cp -a "$CONFIG/agent.env" "$backup/agent.env"
# Keep releases immutable. Different bytes must use a new version identifier.
if [[ -d "$release" ]];then
  cmp "$HERE/SHA256SUMS" "$release/SHA256SUMS" >/dev/null || { echo 'Version already exists with different content' >&2;exit 1; }
else
  staging="$BASE/releases/.staging-$$";install -d -m755 "$staging"
  for file in nowhere-agent nowhere ctl xbctl-wrapper install.sh VERSION SHA256SUMS;do install -m755 "$HERE/$file" "$staging/$file";done
  mv "$staging" "$release"
fi
rollback_error() {
  local result=$?
  trap - ERR
  set +e
  systemctl stop xboard-node-nowhere-managed.service
  previous=$(cat "$backup/previous-release")
  if [[ "$previous" == "$BASE/releases/"* && -x "$previous/nowhere-agent" ]];then
    ln -sfn "$previous" "$BASE/current.next";mv -Tf "$BASE/current.next" "$BASE/current"
  fi
  if [[ -f "$backup/agent.env" ]];then install -m600 "$backup/agent.env" "$CONFIG/agent.env";fi
  if [[ -f "$backup/unit" ]];then
    install -m644 "$backup/unit" "$UNIT"
    systemctl daemon-reload;systemctl start xboard-node-nowhere-managed.service
  else
    systemctl disable xboard-node-nowhere-managed.service >/dev/null 2>&1
    rm -f "$UNIT";systemctl daemon-reload
  fi
  echo "Install failed; previous service restored. Backup: $backup" >&2
  exit "$result"
}
trap rollback_error ERR
systemctl stop xboard-node-nowhere-managed.service || true
# Do not restore or truncate usage.json on upgrades or rollbacks.
if [[ "$secret" != "$CONFIG/control.secret" ]];then install -m600 "$secret" "$CONFIG/control.secret";fi
touch "$CONFIG/security-v3";chmod 600 "$CONFIG/security-v3"
printf 'PANEL_URL=%s\nMACHINE_ID=%s\n' "$panel" "$machine" > "$CONFIG/agent.env"
ln -sfn "$release" "$BASE/current.next";mv -Tf "$BASE/current.next" "$BASE/current"
cat > "$UNIT" <<'EOF'
[Unit]
Description=Nowhere extension for Xboard-Node
After=network-online.target xboard-node.service
Wants=network-online.target
PartOf=xboard-node.service
[Service]
EnvironmentFile=/etc/xboard-node/extensions/nowhere/agent.env
ExecStart=/opt/xboard-node/extensions/nowhere/current/nowhere-agent -panel ${PANEL_URL} -machine-id ${MACHINE_ID} -secret-file /etc/xboard-node/extensions/nowhere/control.secret -binary /opt/xboard-node/extensions/nowhere/current/nowhere -state-dir /var/lib/xboard-node/nowhere
Restart=on-failure
RestartSec=3
KillMode=control-group
TimeoutStopSec=30
UMask=0077
ProtectSystem=strict
ReadWritePaths=/var/lib/xboard-node/nowhere
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectControlGroups=yes
RestrictSUIDSGID=yes
LockPersonality=yes
RestrictNamespaces=yes
CapabilityBoundingSet=
LimitNOFILE=16384
TasksMax=512
[Install]
WantedBy=multi-user.target xboard-node.service
EOF
systemctl daemon-reload
systemctl enable xboard-node-nowhere-managed.service >/dev/null
"$BASE/current/install.sh" --repair-cli
systemctl start xboard-node-nowhere-managed.service
systemctl is-active --quiet xboard-node-nowhere-managed.service
trap - ERR
echo "Installed Nowhere extension $version"
echo "Backup: $backup"
echo 'Main xboard-node binary and database data were not changed.'
