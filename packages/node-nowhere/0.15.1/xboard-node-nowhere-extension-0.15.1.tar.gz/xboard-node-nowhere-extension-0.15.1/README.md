# Xboard-Node Nowhere 节点扩展

此包仅包含节点端 Nowhere 代理、定制多用户内核、systemd/xbctl 集成安装器及对应源码。面板端代码不在此包中。

已有官方 Xboard-Node 时运行 `bash install.sh node --panel https://panel.example.com --machine-id 123 --secret-file /root/machine-token`。已有扩展可运行 `bash install.sh node --check` 后再执行 `bash install.sh node`，自动读取保存的接入参数。

统一部署 Xboard-Node、xbctl 和此扩展，请使用仓库根目录的一键安装脚本 `machine` 模式。

需要 Linux amd64、systemd、Python 3 和兼容的服务端 API。安装器保存凭据为 root 可读文件，备份旧扩展，保留计量状态并开启自启。证书文件需提前准备。

管理：`xbctl nowhere status`、`xbctl nowhere logs`、`xbctl nowhere restart`。

`sources/nowhere-core-source.tar.gz` 与 `sources/agent-source.tar.gz` 包含节点内核和代理对应源码。各组件保留原许可证，Nowhere 内核采用 GPL-3.0-only。
