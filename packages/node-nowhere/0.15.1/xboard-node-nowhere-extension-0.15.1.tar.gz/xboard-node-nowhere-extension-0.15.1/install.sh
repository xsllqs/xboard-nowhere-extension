#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "$0")" && pwd -P)
if [[ ${1:-} == node ]];then shift;fi
exec bash "$here/node/install.sh" "$@"
